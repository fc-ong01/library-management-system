package com.lms.backend.dto;


public class BookDtos {
public static class BookRequest {
public String isbn; public String title; public String author; public String category; public Integer publicationYear; public Integer copiesTotal;
}
public static class BookResponse {
public Long id; public String isbn; public String title; public String author; public String category; public Integer publicationYear; public Integer copiesTotal; public Integer copiesAvailable;
public BookResponse(Long id,String isbn,String title,String author,String category,Integer year,Integer total,Integer avail){
this.id=id; this.isbn=isbn; this.title=title; this.author=author; this.category=category; this.publicationYear=year; this.copiesTotal=total; this.copiesAvailable=avail;
}
}
}