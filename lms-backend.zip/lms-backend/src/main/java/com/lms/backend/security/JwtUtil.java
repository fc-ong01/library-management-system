package com.lms.backend.security;


import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.util.Date;


@Component
public class JwtUtil {
private final Key key;
private final long expMillis;


public JwtUtil(@Value("${app.jwt.secret}") String secret, @Value("${app.jwt.expMinutes:120}") long expMinutes){
this.key = Keys.hmacShaKeyFor(secret.getBytes());
this.expMillis = expMinutes * 60_000L;
}
public String generate(String subject){
long now = System.currentTimeMillis();
return Jwts.builder().setSubject(subject).setIssuedAt(new Date(now)).setExpiration(new Date(now+expMillis)).signWith(key, SignatureAlgorithm.HS256).compact();
}
public String validateAndGetSubject(String token){
try{
return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody().getSubject();
}catch(Exception e){ return null; }
}
}