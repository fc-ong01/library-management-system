package com.lms.backend.repo;


import com.lms.backend.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;


public interface BookRepository extends JpaRepository<Book, Long> {
boolean existsByIsbn(String isbn);
List<Book> findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCaseOrIsbnContainingIgnoreCase(String t,String a,String i);
}