package com.lms.backend.service;


import com.lms.backend.model.*;
import com.lms.backend.repo.LoanRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;


@Service
public class OverdueService {
private final LoanRepository loans;
public OverdueService(LoanRepository loans){ this.loans=loans; }


public BigDecimal computeFine(LocalDate due, LocalDate returned){
if(due==null) return BigDecimal.ZERO;
LocalDate ref = (returned!=null? returned : LocalDate.now());
long days = ChronoUnit.DAYS.between(due.plusDays(1), ref.plusDays(1)); // starts day after due
if(days<=0) return BigDecimal.ZERO;
BigDecimal fine = new BigDecimal(days).multiply(new BigDecimal("0.50"));
if(fine.compareTo(new BigDecimal("20.00"))>0) fine = new BigDecimal("20.00");
return fine;
}


public boolean hasOverdue(Long userId){
return !loans.findByMemberIdAndDueDateBeforeAndStatus(userId, LocalDate.now(), LoanStatus.BORROWED).isEmpty();
}


public BigDecimal totalFines(Long userId){
return loans.findByMemberId(userId).stream()
.map(l-> computeFine(l.dueDate, l.returnedAt))
.reduce(BigDecimal.ZERO, BigDecimal::add);
}
}