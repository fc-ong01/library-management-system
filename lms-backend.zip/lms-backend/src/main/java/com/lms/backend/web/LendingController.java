package com.lms.backend.web;


import com.lms.backend.model.Loan;
import com.lms.backend.service.LendingService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;


@RestController @RequestMapping("/api/lending")
public class LendingController {
private final LendingService svc;
public LendingController(LendingService svc){ this.svc=svc; }


@GetMapping("/my") public List<Loan> my(@AuthenticationPrincipal String email){ return svc.myLoans(email); }
@GetMapping("/summary") public LendingService.Summary sum(@AuthenticationPrincipal String email){ return svc.summary(email); }
@PostMapping("/borrow") public void borrow(@AuthenticationPrincipal String email, @RequestBody Map<String,Long> r){ svc.borrow(email, r.get("bookId")); }
@PostMapping("/renew") public void renew(@AuthenticationPrincipal String email, @RequestBody Map<String,Long> r){ svc.renew(email, r.get("loanId")); }
@PostMapping("/return") public void ret(@AuthenticationPrincipal String email, @RequestBody Map<String,Long> r){ svc.returnBook(email, r.get("loanId")); }
@PostMapping("/reserve") public void reserve(@AuthenticationPrincipal String email, @RequestBody Map<String,Long> r){ svc.reserve(email, r.get("bookId")); }
}