package com.lms.backend.web;


import com.lms.backend.dto.MemberDtos.*;
import com.lms.backend.service.MemberService;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController @RequestMapping("/api/members")
public class MemberController {
private final MemberService svc;
public MemberController(MemberService svc){ this.svc=svc; }


@GetMapping public List<MemberResponse> search(@RequestParam(required=false) String q){ return svc.search(q); }
@PostMapping public void create(@RequestBody MemberUpsertRequest req){ svc.create(req); }
@PutMapping("/{id}") public void update(@PathVariable Long id,@RequestBody MemberUpsertRequest req){ svc.update(id,req); }
@DeleteMapping("/{id}") public void delete(@PathVariable Long id){ svc.delete(id); }
}