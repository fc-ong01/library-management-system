package com.lms.backend.service;


import com.lms.backend.dto.AuthDtos.*;
import com.lms.backend.model.*;
import com.lms.backend.repo.*;
import com.lms.backend.security.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.*;
import java.util.UUID;


@Service
public class AuthService {
private final UserRepository users; private final PasswordEncoder enc; private final JwtUtil jwt; private final PasswordResetTokenRepository tokens;
public AuthService(UserRepository users, PasswordEncoder enc, JwtUtil jwt, PasswordResetTokenRepository tokens){ this.users=users; this.enc=enc; this.jwt=jwt; this.tokens=tokens; }


public void register(RegisterRequest req){
if(users.existsByEmail(req.email)) throw new RuntimeException("Email already registered");
User u = new User();
u.email = req.email; u.passwordHash = enc.encode(req.password);
u.fullName=req.fullName; u.address=req.address; u.phone=req.phone; u.enabled=true;
u.role = req.librarian? Role.LIBRARIAN : Role.MEMBER;
u.membershipValidUntil = LocalDate.now().plusYears(1);
users.save(u);
}


public JwtResponse login(LoginRequest req){
var u = users.findByEmail(req.email).orElseThrow(()->new RuntimeException("Bad credentials"));
if(!u.enabled || !enc.matches(req.password, u.passwordHash)) throw new RuntimeException("Bad credentials");
return new JwtResponse(jwt.generate(u.email), u.role.name());
}


public void forgotPassword(ForgotPasswordRequest req){
var u = users.findByEmail(req.email).orElseThrow(()->new RuntimeException("No such email"));
var t = new PasswordResetToken();
t.user=u; t.token=UUID.randomUUID().toString().replace("-",""); t.expiresAt=Instant.now().plusSeconds(15*60);
tokens.save(t);
// Email if configured; otherwise log
System.out.println("[DEV] Password reset token for "+u.email+": "+t.token);
}


public void resetPassword(ResetPasswordRequest req){
var t = tokens.findByToken(req.token).orElseThrow(()->new RuntimeException("Invalid token"));
if(t.used || t.expiresAt.isBefore(Instant.now())) throw new RuntimeException("Invalid token");
var u = t.user; u.passwordHash = enc.encode(req.newPassword); users.save(u);
t.used = true; tokens.save(t);
}
}