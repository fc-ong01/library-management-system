package com.lms.backend.model;


import jakarta.persistence.*;


@Entity @Table(name="books")
public class Book {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
public Long id;


@Column(nullable = false, unique = true)
public String isbn;


@Column(nullable = false)
public String title;


@Column(nullable = false)
public String author;


public String category;
public Integer publicationYear;


@Column(nullable = false)
public Integer copiesTotal = 1;


@Column(nullable = false)
public Integer copiesAvailable = 1; // maintained by lending service
}