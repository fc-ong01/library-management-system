package com.lms.backend.web;


import com.lms.backend.dto.BookDtos.*;
import com.lms.backend.model.Book;
import com.lms.backend.service.BookService;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController @RequestMapping("/api/books")
public class BookController {
private final BookService svc;
public BookController(BookService svc){ this.svc=svc; }


@GetMapping public List<Book> search(@RequestParam(required=false) String q){ return svc.search(q); }
@PostMapping public void add(@RequestBody BookRequest r){ svc.add(r); }
@PutMapping("/{id}") public void upd(@PathVariable Long id,@RequestBody BookRequest r){ svc.update(id,r); }
@DeleteMapping("/{id}") public void del(@PathVariable Long id){ svc.delete(id); }
}