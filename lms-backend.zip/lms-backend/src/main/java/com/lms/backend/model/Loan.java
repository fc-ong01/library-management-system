package com.lms.backend.model;


import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;


@Entity @Table(name="loans")
public class Loan {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
public Long id;


@ManyToOne(optional = false)
public User member;


@ManyToOne(optional = false)
public Book book;


public LocalDate borrowedAt;
public LocalDate dueDate;
public LocalDate returnedAt;


@Enumerated(EnumType.STRING)
public LoanStatus status = LoanStatus.BORROWED;


public int renewals = 0; // max 2


@Column(precision = 10, scale = 2)
public BigDecimal fineAmount = BigDecimal.ZERO; // computed on return
}