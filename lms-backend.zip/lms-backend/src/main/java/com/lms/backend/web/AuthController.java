package com.lms.backend.web;


import com.lms.backend.dto.AuthDtos.*;
import com.lms.backend.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController @RequestMapping("/api/auth")
public class AuthController {
private final AuthService svc;
public AuthController(AuthService svc){ this.svc=svc; }


@PostMapping("/register") public ResponseEntity<?> register(@RequestBody RegisterRequest r){ svc.register(r); return ResponseEntity.ok().build(); }
@PostMapping("/login") public JwtResponse login(@RequestBody LoginRequest r){ return svc.login(r); }
@PostMapping("/forgot-password") public ResponseEntity<?> forgot(@RequestBody ForgotPasswordRequest r){ svc.forgotPassword(r); return ResponseEntity.ok().build(); }
@PostMapping("/reset-password") public ResponseEntity<?> reset(@RequestBody ResetPasswordRequest r){ svc.resetPassword(r); return ResponseEntity.ok().build(); }
}