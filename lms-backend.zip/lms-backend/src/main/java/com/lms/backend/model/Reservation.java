package com.lms.backend.model;


import jakarta.persistence.*;
import java.time.LocalDate;


@Entity @Table(name="reservations")
public class Reservation {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
public Long id;


@ManyToOne(optional = false)
public User member;


@ManyToOne(optional = false)
public Book book;


public LocalDate reservedAt = LocalDate.now();
}