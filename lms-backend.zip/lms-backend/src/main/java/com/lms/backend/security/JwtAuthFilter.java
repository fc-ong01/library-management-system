package com.lms.backend.security;


import com.lms.backend.model.User;
import com.lms.backend.repo.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;


@Component
public class JwtAuthFilter extends OncePerRequestFilter {
private final JwtUtil jwt; private final UserRepository users;
public JwtAuthFilter(JwtUtil jwt, UserRepository users){ this.jwt=jwt; this.users=users; }
@Override protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws ServletException, IOException {
String auth = req.getHeader("Authorization");
if(auth!=null && auth.startsWith("Bearer ")){
String sub = jwt.validateAndGetSubject(auth.substring(7));
if(sub!=null){
users.findByEmail(sub).ifPresent(u->{
var authz = new UsernamePasswordAuthenticationToken(u.email, null, List.of(new SimpleGrantedAuthority("ROLE_"+u.role.name())));
SecurityContextHolder.getContext().setAuthentication(authz);
});
}
}
chain.doFilter(req,res);
}
}