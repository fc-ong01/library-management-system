package com.lms.backend.model;
public enum LoanStatus { BORROWED, RETURNED }