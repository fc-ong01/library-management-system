package com.lms.backend.model;


import jakarta.persistence.*;
import java.time.Instant;


@Entity @Table(name="password_reset_tokens")
public class PasswordResetToken {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
public Long id;


@ManyToOne(optional = false)
public User user;


@Column(nullable = false, unique = true)
public String token;


public Instant expiresAt;
public boolean used = false;
}