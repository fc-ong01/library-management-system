package com.lms.backend.repo;


import com.lms.backend.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;


public interface LoanRepository extends JpaRepository<Loan, Long> {
List<Loan> findByMemberIdAndStatus(Long userId, LoanStatus status);
long countByMemberIdAndStatus(Long userId, LoanStatus status);
List<Loan> findByMemberId(Long userId);
List<Loan> findByMemberIdAndDueDateBeforeAndStatus(Long userId, LocalDate date, LoanStatus status);
}