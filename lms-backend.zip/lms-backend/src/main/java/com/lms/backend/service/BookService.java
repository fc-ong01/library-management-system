package com.lms.backend.service;


import com.lms.backend.dto.BookDtos.*;
import com.lms.backend.model.Book;
import com.lms.backend.repo.BookRepository;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class BookService {
private final BookRepository books;
public BookService(BookRepository books){ this.books=books; }


public void add(BookRequest req){
if(books.existsByIsbn(req.isbn)) throw new RuntimeException("ISBN already exists");
Book b = new Book();
b.isbn=req.isbn; b.title=req.title; b.author=req.author; b.category=req.category; b.publicationYear=req.publicationYear;
b.copiesTotal = req.copiesTotal==null?1:req.copiesTotal; b.copiesAvailable = b.copiesTotal;
books.save(b);
}


public void update(Long id, BookRequest req){
var b = books.findById(id).orElseThrow(()->new RuntimeException("Book not found"));
b.title=req.title; b.author=req.author; b.category=req.category; b.publicationYear=req.publicationYear; b.copiesTotal=req.copiesTotal;
// keep copiesAvailable sane
if(b.copiesAvailable> b.copiesTotal) b.copiesAvailable=b.copiesTotal;
books.save(b);
}


public void delete(Long id){ books.deleteById(id); }


public List<Book> search(String q){
if(q==null || q.isBlank()) return books.findAll();
return books.findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCaseOrIsbnContainingIgnoreCase(q,q,q);
}
}