package com.lms.backend.dto;


public class AuthDtos {
public static class LoginRequest { public String email; public String password; }
public static class RegisterRequest {
public String fullName; public String email; public String password; public String address; public String phone; public boolean librarian;
}
public static class JwtResponse { public String token; public String role; public JwtResponse(String t,String r){token=t;role=r;} }
public static class ForgotPasswordRequest { public String email; }
public static class ResetPasswordRequest { public String token; public String newPassword; }
}