package com.lms.backend.dto;


import java.time.LocalDate;


public class MemberDtos {
public static class MemberResponse {
public Long id; public String email; public String fullName; public String address; public String phone; public LocalDate membershipValidUntil;
public MemberResponse(Long id,String email,String fullName,String address,String phone,LocalDate membershipValidUntil){
this.id=id; this.email=email; this.fullName=fullName; this.address=address; this.phone=phone; this.membershipValidUntil=membershipValidUntil;
}
}
public static class MemberUpsertRequest { public String fullName; public String email; public String address; public String phone; }
}