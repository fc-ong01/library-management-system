package com.lms.backend.model;


import jakarta.persistence.*;
import java.time.LocalDate;


@Entity @Table(name = "users")
public class User {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
public Long id;


@Column(nullable = false, unique = true)
public String email;


@Column(name = "password_hash", nullable = false)
public String passwordHash; // BCrypt hash only


@Enumerated(EnumType.STRING)
@Column(nullable = false)
public Role role = Role.MEMBER;


public String fullName;
public String address;
public String phone;


@Column(nullable = false)
public boolean enabled = true;


public LocalDate membershipValidUntil; // must be in future to borrow
public LocalDate registeredAt = LocalDate.now();
}