package com.lms.backend.service;


import com.lms.backend.dto.MemberDtos.*;
import com.lms.backend.model.*;
import com.lms.backend.repo.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class MemberService {
private final UserRepository users;
public MemberService(UserRepository users){ this.users=users; }


public List<MemberResponse> search(String q){
return users.findAll().stream()
.filter(u->u.role==Role.MEMBER || u.role==Role.LIBRARIAN)
.filter(u-> q==null || q.isBlank() || (u.fullName!=null && u.fullName.toLowerCase().contains(q.toLowerCase())) || u.email.toLowerCase().contains(q.toLowerCase()))
.map(u-> new MemberResponse(u.id,u.email,u.fullName,u.address,u.phone,u.membershipValidUntil))
.collect(Collectors.toList());
}


public void create(MemberUpsertRequest req){
if(users.existsByEmail(req.email)) throw new RuntimeException("Email already registered");
var u = new User();
u.email=req.email; u.fullName=req.fullName; u.address=req.address; u.phone=req.phone; u.role=Role.MEMBER; u.enabled=true;
u.membershipValidUntil = LocalDate.now().plusYears(1);
// temp password; user can reset via forgot-password
u.passwordHash = new BCryptPasswordEncoder().encode("Password123");
users.save(u);
}


public void update(Long id, MemberUpsertRequest req){
var u = users.findById(id).orElseThrow(()->new RuntimeException("Member not found"));
if(req.fullName!=null) u.fullName=req.fullName; if(req.address!=null) u.address=req.address; if(req.phone!=null) u.phone=req.phone;
users.save(u);
}


public void delete(Long id){ users.deleteById(id); }
}