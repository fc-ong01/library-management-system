package com.lms.backend.web;


import com.lms.backend.model.*;
import com.lms.backend.repo.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;


@RestController @RequestMapping("/api/auth")
public class BootstrapController {
private final UserRepository users; private final PasswordEncoder enc;
public BootstrapController(UserRepository users, PasswordEncoder enc){ this.users=users; this.enc=enc; }


@GetMapping("/bootstrap-admin")
public String bootstrap(){
if(users.existsByEmail("admin@library.com")) return "Skipped";
User u = new User(); u.email="admin@library.com"; u.fullName="Admin User"; u.role=Role.LIBRARIAN; u.enabled=true; u.membershipValidUntil=LocalDate.now().plusYears(5);
u.passwordHash=enc.encode("Password123"); users.save(u); return "Admin created";
}
}