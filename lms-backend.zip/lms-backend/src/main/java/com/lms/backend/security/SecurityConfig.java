package com.lms.backend.security;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.beans.factory.annotation.Value;
import java.util.List;


@Configuration
public class SecurityConfig {
private final JwtAuthFilter jwt;
public SecurityConfig(JwtAuthFilter jwt){ this.jwt=jwt; }


@Bean PasswordEncoder passwordEncoder(){ return new BCryptPasswordEncoder(); }
@Bean AuthenticationManager authManager(AuthenticationConfiguration cfg) throws Exception { return cfg.getAuthenticationManager(); }


@Bean SecurityFilterChain chain(HttpSecurity http) throws Exception {
http.csrf(csrf->csrf.disable())
.sessionManagement(sm->sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
.authorizeHttpRequests(reg->reg
.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
.requestMatchers("/api/auth/**").permitAll()
.requestMatchers(HttpMethod.GET, "/api/books/**").authenticated()
.requestMatchers("/api/books/**", "/api/members/**").hasRole("LIBRARIAN")
.requestMatchers("/api/lending/**", "/api/me").authenticated()
.anyRequest().denyAll())
.addFilterBefore(jwt, UsernamePasswordAuthenticationFilter.class)
.cors(c->{});
return http.build();
}


@Bean CorsConfigurationSource corsSource(@Value("${app.cors.origins:http://localhost:3000}") String origins){
var cfg = new CorsConfiguration();
cfg.setAllowedOrigins(List.of(origins.split(",")));
cfg.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));
cfg.setAllowedHeaders(List.of("*"));
cfg.setAllowCredentials(true);
var src = new UrlBasedCorsConfigurationSource();
src.registerCorsConfiguration("/**", cfg);
return src;
}
}