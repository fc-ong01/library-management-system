package com.lms.backend.model;
public enum Role { LIBRARIAN, MEMBER }