package com.lms.backend.service;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lms.backend.model.Loan;
import com.lms.backend.model.LoanStatus;
import com.lms.backend.model.Reservation;
import com.lms.backend.repo.BookRepository;
import com.lms.backend.repo.LoanRepository;
import com.lms.backend.repo.ReservationRepository;
import com.lms.backend.repo.UserRepository;


@Service
public class LendingService {
private final UserRepository users; private final BookRepository books; private final LoanRepository loans; private final ReservationRepository reserves; private final OverdueService overdue;
public LendingService(UserRepository users, BookRepository books, LoanRepository loans, ReservationRepository reserves, OverdueService overdue){
this.users=users; this.books=books; this.loans=loans; this.reserves=reserves; this.overdue=overdue; }


public List<Loan> myLoans(String email){
var u = users.findByEmail(email).orElseThrow();
return loans.findByMemberId(u.id);
}


public record Summary(int activeBorrowed,int overdueCount, java.math.BigDecimal totalFines){}
public Summary summary(String email){
var u = users.findByEmail(email).orElseThrow();
int active = (int) loans.countByMemberIdAndStatus(u.id, LoanStatus.BORROWED);
int over = loans.findByMemberIdAndDueDateBeforeAndStatus(u.id, LocalDate.now(), LoanStatus.BORROWED).size();
var fines = overdue.totalFines(u.id);
return new Summary(active, over, fines);
}


public void borrow(String email, Long bookId){
var u = users.findByEmail(email).orElseThrow();
if(u.membershipValidUntil==null || !u.membershipValidUntil.isAfter(LocalDate.now())) throw new RuntimeException("Membership expired");
if(overdue.hasOverdue(u.id)) throw new RuntimeException("You have overdue loans");
if(overdue.totalFines(u.id).compareTo(new java.math.BigDecimal("10.00"))>0) throw new RuntimeException("Outstanding fines exceed $10");
if(loans.countByMemberIdAndStatus(u.id, LoanStatus.BORROWED) >= 3) throw new RuntimeException("Borrowing limit reached (3)");


var b = books.findById(bookId).orElseThrow(()->new RuntimeException("Book not found"));
if(b.copiesAvailable<=0) throw new RuntimeException("No available copies");


var l = new Loan(); l.member=u; l.book=b; l.borrowedAt=LocalDate.now(); l.dueDate=LocalDate.now().plusDays(14); l.status=LoanStatus.BORROWED; l.renewals=0;
loans.save(l);
b.copiesAvailable -= 1; books.save(b);
}


public void renew(String email, Long loanId){
var u = users.findByEmail(email).orElseThrow();
var l = loans.findById(loanId).orElseThrow(()->new RuntimeException("Loan not found"));
if(!l.member.id.equals(u.id)) throw new RuntimeException("Not your loan");
if(l.status!=LoanStatus.BORROWED) throw new RuntimeException("Loan not active");
if(l.renewals>=2) throw new RuntimeException("Max renewals reached");
if(l.dueDate.isBefore(LocalDate.now())) throw new RuntimeException("Cannot renew overdue loan");
l.dueDate = l.dueDate.plusDays(14); l.renewals += 1; loans.save(l);
}


public void returnBook(String email, Long loanId){
var u = users.findByEmail(email).orElseThrow();
var l = loans.findById(loanId).orElseThrow(()->new RuntimeException("Loan not found"));
if(!l.member.id.equals(u.id)) throw new RuntimeException("Not your loan");
if(l.status!=LoanStatus.BORROWED) throw new RuntimeException("Already returned");
l.returnedAt = LocalDate.now(); l.status = LoanStatus.RETURNED;
// compute fine
var fine = overdue.computeFine(l.dueDate, l.returnedAt); l.fineAmount=fine; loans.save(l);
// free a copy
var b = l.book; b.copiesAvailable += 1; books.save(b);
// fulfill a reservation if any (simple: do nothing; UI could notify)
}


public void reserve(String email, Long bookId){
var u = users.findByEmail(email).orElseThrow();
var b = books.findById(bookId).orElseThrow();
if(b.copiesAvailable>0) throw new RuntimeException("Book is available; borrow instead");
if(reserves.existsByBookIdAndMemberId(bookId, u.id)) throw new RuntimeException("Already reserved");
var r = new Reservation(); r.book=b; r.member=u; reserves.save(r);
}
}