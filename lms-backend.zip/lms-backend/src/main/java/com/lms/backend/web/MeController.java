package com.lms.backend.web;


import com.lms.backend.model.User;
import com.lms.backend.repo.UserRepository;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.http.ResponseEntity;
import java.util.Map;


@RestController
public class MeController {
private final UserRepository users;
public MeController(UserRepository users){ this.users=users; }


@GetMapping("/api/me")
public Map<String,Object> me(@AuthenticationPrincipal String email){
User u = users.findByEmail(email).orElseThrow();
return Map.of("id",u.id,"email",u.email,"role",u.role.name(),"fullName",u.fullName,"address",u.address,"phone",u.phone,"membershipValidUntil",u.membershipValidUntil);
}


@PutMapping("/api/me")
public ResponseEntity<?> update(@AuthenticationPrincipal String email, @RequestBody Map<String,String> r){
User u = users.findByEmail(email).orElseThrow();
u.fullName=r.getOrDefault("fullName", u.fullName);
u.address=r.getOrDefault("address", u.address);
u.phone=r.getOrDefault("phone", u.phone);
users.save(u);
return ResponseEntity.ok().build();
}
}