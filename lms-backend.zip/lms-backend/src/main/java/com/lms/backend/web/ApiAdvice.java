package com.lms.backend.web;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.util.Map;


@RestControllerAdvice
public class ApiAdvice {
@ExceptionHandler({RuntimeException.class, IllegalArgumentException.class, MethodArgumentNotValidException.class})
public ResponseEntity<?> handle(Exception e){ return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
}