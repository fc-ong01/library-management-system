package com.lms.backend.repo;


import com.lms.backend.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;


public interface ReservationRepository extends JpaRepository<Reservation, Long> {
Optional<Reservation> findFirstByBookIdOrderByReservedAtAsc(Long bookId);
boolean existsByBookIdAndMemberId(Long bookId, Long memberId);
}