Library Backend (Spring Boot 3 + MySQL + JWT + Overdue + Password Reset)
----------------------------------------------------------------------------
Quick start (Windows CMD):

  set "DB_URL=jdbc:mysql://127.0.0.1:3306/library_data?allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC"
  set "DB_USER=library_user"
  set "DB_PASS=password123"
  set "JWT_SECRET=This-Is-A-VERY-LONG-Secret-Key-At-Least-64-Characters-OK"
  mvn spring-boot:run

Notes:
- On first run, a default Librarian is created:
    email: admin@library.com
    password: AdminPass123
  (You can disable this by setting app.bootstrap-admin=false in application.properties)

Endpoints:
- POST   /api/auth/login           {{email,password}} -> {{token, role}}
- POST   /api/auth/register        {{fullName,email,password,address,phone,librarian}}
- POST   /api/auth/forgot-password {{email}}
- POST   /api/auth/reset-password  {{token,newPassword}}
- GET    /api/me, PUT /api/me

Librarian only:
- GET/POST/PUT/DELETE /api/books
- GET/POST/PUT/DELETE /api/members

Member lending:
- GET    /api/lending/my
- GET    /api/lending/summary
- POST   /api/lending/borrow   {{bookId}}
- POST   /api/lending/return   {{loanId}}
- POST   /api/lending/renew    {{loanId}}
- POST   /api/lending/reserve  {{bookId}}

Business rules:
- Max 3 concurrent borrowed books
- Loan 14 days; max 2 renewals; no renewals if overdue
- Fine $0.50/day after due date, capped at $20/book
- Block borrowing if any overdue OR total fines > $10 OR membership expired

CORS:
- Allowed origins via FRONTEND_ORIGINS env (default http://localhost:3000)
