package com.lms.model;

public enum BorrowStatus {
    ACTIVE,
    RETURNED,
    OVERDUE
}