package com.lms.model;

public enum BookStatus {
    AVAILABLE,
    BORROWED,
    RESERVED,
    MAINTENANCE
}