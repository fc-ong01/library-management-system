import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Container, 
  Typography, 
  Button, 
  Box, 
  Grid, 
  Card, 
  CardContent 
} from '@mui/material';
import { 
  Book, 
  People, 
  LibraryBooks, 
  AccountCircle 
} from '@mui/icons-material';

const Home = () => {
  return (
    <Container maxWidth="lg">
      {/* Hero Section */}
      <Box 
        sx={{ 
          textAlign: 'center', 
          py: 8,
          background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
          color: 'white',
          borderRadius: 2,
          mb: 6
        }}
      >
        <Typography variant="h2" component="h1" gutterBottom>
          Welcome to Library Management System
        </Typography>
        <Typography variant="h5" component="p" gutterBottom>
          Manage your library resources efficiently with our comprehensive system
        </Typography>
        <Box sx={{ mt: 4, gap: 2, display: 'flex', justifyContent: 'center' }}>
          <Button 
            variant="contained" 
            color="secondary" 
            size="large"
            component={Link}
            to="/login"
          >
            Login
          </Button>
          <Button 
            variant="outlined" 
            color="inherit" 
            size="large"
            component={Link}
            to="/register"
          >
            Register
          </Button>
        </Box>
      </Box>

      {/* Features Section */}
      <Typography variant="h3" component="h2" textAlign="center" gutterBottom>
        Features
      </Typography>
      <Grid container spacing={4} sx={{ mb: 6 }}>
        <Grid item xs={12} md={6} lg={3}>
          <Card sx={{ height: '100%', textAlign: 'center' }}>
            <CardContent>
              <Book sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h5" component="h3" gutterBottom>
                Book Management
              </Typography>
              <Typography variant="body1">
                Add, update, and manage your library's book collection with ease.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6} lg={3}>
          <Card sx={{ height: '100%', textAlign: 'center' }}>
            <CardContent>
              <People sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h5" component="h3" gutterBottom>
                User Management
              </Typography>
              <Typography variant="body1">
                Manage members and librarians with different access levels.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6} lg={3}>
          <Card sx={{ height: '100%', textAlign: 'center' }}>
            <CardContent>
              <LibraryBooks sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h5" component="h3" gutterBottom>
                Lending System
              </Typography>
              <Typography variant="body1">
                Track book borrowings, returns, and manage reservations.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6} lg={3}>
          <Card sx={{ height: '100%', textAlign: 'center' }}>
            <CardContent>
              <AccountCircle sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h5" component="h3" gutterBottom>
                Fine Calculation
              </Typography>
              <Typography variant="body1">
                Automated fine calculation for overdue books with payment tracking.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Stats Section */}
      <Box sx={{ background: '#f5f5f5', p: 4, borderRadius: 2, textAlign: 'center' }}>
        <Typography variant="h4" component="h2" gutterBottom>
          Library Statistics
        </Typography>
        <Grid container spacing={3} sx={{ mt: 2 }}>
          <Grid item xs={12} md={4}>
            <Typography variant="h3" component="div" color="primary">
              1,250+
            </Typography>
            <Typography variant="h6">Books in Collection</Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Typography variant="h3" component="div" color="primary">
              500+
            </Typography>
            <Typography variant="h6">Active Members</Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Typography variant="h3" component="div" color="primary">
              50+
            </Typography>
            <Typography variant="h6">Daily Transactions</Typography>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default Home;