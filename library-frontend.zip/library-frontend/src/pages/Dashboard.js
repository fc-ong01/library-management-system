import React from 'react';
import { Container, Typography, Paper, Grid, Card, CardContent, Box } from '@mui/material';
import { Book, People, LibraryBooks, AccountCircle } from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';

const Dashboard = () => {
  const { currentUser } = useAuth();

  return (
    <Container maxWidth="lg">
      <Typography variant="h4" component="h1" gutterBottom sx={{ mb: 4 }}>
        Dashboard
      </Typography>

      {currentUser && (
        <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Welcome, {currentUser.firstName} {currentUser.lastName}
          </Typography>
          <Typography variant="body1" color="textSecondary">
            Email: {currentUser.email}
          </Typography>
          <Typography variant="body1" color="textSecondary">
            Role: {currentUser.role}
          </Typography>
        </Paper>
      )}

      <Grid container spacing={4}>
        <Grid item xs={12} md={6} lg={3}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Book sx={{ fontSize: 40, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6">Total Books</Typography>
              <Typography variant="h4" color="primary">
                1,250
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6} lg={3}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <People sx={{ fontSize: 40, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6">Total Members</Typography>
              <Typography variant="h4" color="primary">
                500
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6} lg={3}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <LibraryBooks sx={{ fontSize: 40, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6">Active Borrowings</Typography>
              <Typography variant="h4" color="primary">
                150
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6} lg={3}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <AccountCircle sx={{ fontSize: 40, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6">Overdue Books</Typography>
              <Typography variant="h4" color="primary">
                12
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Recent Activity Section */}
      <Box sx={{ mt: 6 }}>
        <Typography variant="h5" gutterBottom>
          Recent Activity
        </Typography>
        <Paper elevation={2} sx={{ p: 3 }}>
          <Typography variant="body1" color="textSecondary">
            No recent activity to display.
          </Typography>
        </Paper>
      </Box>
    </Container>
  );
};

export default Dashboard;