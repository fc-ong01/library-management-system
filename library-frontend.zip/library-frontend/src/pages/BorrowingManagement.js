import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Box,
  Chip,
  Alert,
  Button
} from '@mui/material';
import { Refresh } from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';

const BorrowingManagement = () => {
  const [borrowings, setBorrowings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { currentUser } = useAuth();

  useEffect(() => {
    fetchBorrowings();
  }, []);

  const fetchBorrowings = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get('/member/borrowings');
      setBorrowings(response.data);
    } catch (error) {
      setError('Failed to fetch borrowings');
    } finally {
      setLoading(false);
    }
  };

  const handleReturnBook = async (borrowingId) => {
    try {
      await api.post(`/member/borrowings/${borrowingId}/return`);
      fetchBorrowings(); // Refresh the list
    } catch (error) {
      setError('Failed to return book');
    }
  };

  const handleRenewBook = async (borrowingId) => {
    try {
      await api.post(`/member/borrowings/${borrowingId}/renew`);
      fetchBorrowings(); // Refresh the list
    } catch (error) {
      setError('Failed to renew book');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ACTIVE': return 'success';
      case 'OVERDUE': return 'error';
      case 'RETURNED': return 'info';
      default: return 'default';
    }
  };

  if (currentUser.role !== 'MEMBER') {
    return (
      <Container>
        <Alert severity="error">Unauthorized access. Member role required.</Alert>
      </Container>
    );
  }

  return (
    <Container>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">My Borrowings</Typography>
        <Button
          variant="outlined"
          startIcon={<Refresh />}
          onClick={fetchBorrowings}
          disabled={loading}
        >
          Refresh
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Book Title</TableCell>
              <TableCell>Author</TableCell>
              <TableCell>Borrow Date</TableCell>
              <TableCell>Due Date</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {borrowings.map((borrowing) => (
              <TableRow key={borrowing.id}>
                <TableCell>{borrowing.book?.title}</TableCell>
                <TableCell>{borrowing.book?.author}</TableCell>
                <TableCell>{new Date(borrowing.borrowDate).toLocaleDateString()}</TableCell>
                <TableCell>{new Date(borrowing.dueDate).toLocaleDateString()}</TableCell>
                <TableCell>
                  <Chip 
                    label={borrowing.status} 
                    color={getStatusColor(borrowing.status)} 
                    size="small" 
                  />
                </TableCell>
                <TableCell>
                  {borrowing.status === 'ACTIVE' && (
                    <>
                      <Button
                        size="small"
                        onClick={() => handleReturnBook(borrowing.id)}
                        sx={{ mr: 1 }}
                      >
                        Return
                      </Button>
                      <Button
                        size="small"
                        onClick={() => handleRenewBook(borrowing.id)}
                      >
                        Renew
                      </Button>
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {borrowings.length === 0 && !loading && (
        <Paper sx={{ p: 3, mt: 3, textAlign: 'center' }}>
          <Typography variant="h6" color="textSecondary">
            No books borrowed yet.
          </Typography>
        </Paper>
      )}
    </Container>
  );
};

export default BorrowingManagement;