import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Paper,
  TextField,
  Button,
  Box,
  Alert,
  Divider,
  Chip
} from '@mui/material';
import { Save, Edit } from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';

const Profile = () => {
  const { currentUser } = useAuth();
  const [user, setUser] = useState(null);
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    phoneNumber: ''
  });

  useEffect(() => {
    if (currentUser) {
      setUser(currentUser);
      setFormData({
        firstName: currentUser.firstName,
        lastName: currentUser.lastName,
        email: currentUser.email,
        address: currentUser.address || '',
        phoneNumber: currentUser.phoneNumber || ''
      });
    }
  }, [currentUser]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await api.put('/auth/profile', formData);
      setUser(response.data);
      setSuccess('Profile updated successfully');
      setEditing(false);
    } catch (error) {
      setError(error.response?.data?.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <Container>
        <Typography>Loading...</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="md">
      <Typography variant="h4" component="h1" gutterBottom>
        My Profile
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Paper elevation={3} sx={{ p: 4 }}>
        {/* User Info */}
        <Box sx={{ mb: 3 }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Personal Information</Typography>
            <Button
              startIcon={<Edit />}
              onClick={() => setEditing(!editing)}
              variant="outlined"
            >
              {editing ? 'Cancel' : 'Edit'}
            </Button>
          </Box>

          <form onSubmit={handleSubmit}>
            <Box sx={{ mb: 3 }}>
              <TextField
                margin="normal"
                label="First Name"
                fullWidth
                required
                value={formData.firstName}
                onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                disabled={!editing || loading}
              />
              <TextField
                margin="normal"
                label="Last Name"
                fullWidth
                required
                value={formData.lastName}
                onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                disabled={!editing || loading}
              />
              <TextField
                margin="normal"
                label="Email"
                type="email"
                fullWidth
                required
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                disabled={!editing || loading}
              />
              <TextField
                margin="normal"
                label="Phone Number"
                fullWidth
                value={formData.phoneNumber}
                onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
                disabled={!editing || loading}
              />
              <TextField
                margin="normal"
                label="Address"
                fullWidth
                multiline
                rows={3}
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                disabled={!editing || loading}
              />
            </Box>

            {editing && (
              <Button
                type="submit"
                variant="contained"
                startIcon={<Save />}
                disabled={loading}
                sx={{ mr: 2 }}
              >
                Save Changes
              </Button>
            )}
          </form>
        </Box>

        <Divider sx={{ my: 3 }} />

        {/* Account Info */}
        <Box>
          <Typography variant="h6" gutterBottom>
            Account Information
          </Typography>
          <Box sx={{ mb: 2 }}>
            <Chip 
              label={`Role: ${user.role}`} 
              color="primary" 
              variant="outlined"
              sx={{ mr: 1 }}
            />
            <Chip 
              label={`Status: ${user.enabled ? 'Active' : 'Inactive'}`} 
              color={user.enabled ? 'success' : 'error'} 
              variant="outlined"
            />
          </Box>
          <Typography variant="body2" color="textSecondary">
            Member since: {new Date(user.registrationDate).toLocaleDateString()}
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Membership expires: {new Date(user.membershipExpiry).toLocaleDateString()}
          </Typography>
        </Box>
      </Paper>
    </Container>
  );
};

export default Profile;