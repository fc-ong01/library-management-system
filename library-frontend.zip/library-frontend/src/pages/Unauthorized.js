import React from 'react';
import { Container, Typography, Paper, Button } from '@mui/material';
import { Home } from '@mui/icons-material';
import { Link } from 'react-router-dom';

const Unauthorized = () => {
  return (
    <Container maxWidth="sm">
      <Paper elevation={3} sx={{ p: 4, mt: 8, textAlign: 'center' }}>
        <Typography variant="h4" color="error" gutterBottom>
          Access Denied
        </Typography>
        <Typography variant="body1" sx={{ mb: 3 }}>
          You don't have permission to access this page.
        </Typography>
        <Button
          variant="contained"
          component={Link}
          to="/"
          startIcon={<Home />}
        >
          Go Home
        </Button>
      </Paper>
    </Container>
  );
};

export default Unauthorized;