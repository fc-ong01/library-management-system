import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Box,
  IconButton,
  Alert
} from '@mui/material';
import { Edit, Delete, Add, Search } from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';

const BookManagement = () => {
  const [books, setBooks] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingBook, setEditingBook] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { currentUser } = useAuth();

  const [formData, setFormData] = useState({
    isbn: '',
    title: '',
    author: '',
    category: '',
    publicationYear: '',
    totalCopies: ''
  });

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await api.get('/books');
      setBooks(response.data);
    } catch (error) {
      setError('Failed to fetch books');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      if (editingBook) {
        await api.put(`/books/${editingBook.id}`, formData);
        setSuccess('Book updated successfully');
      } else {
        await api.post('/books', formData);
        setSuccess('Book added successfully');
      }
      setOpenDialog(false);
      setEditingBook(null);
      setFormData({
        isbn: '',
        title: '',
        author: '',
        category: '',
        publicationYear: '',
        totalCopies: ''
      });
      fetchBooks();
    } catch (error) {
      setError(error.response?.data?.message || 'Failed to save book');
    }
  };

  const handleEdit = (book) => {
    setEditingBook(book);
    setFormData({
      isbn: book.isbn,
      title: book.title,
      author: book.author,
      category: book.category,
      publicationYear: book.publicationYear,
      totalCopies: book.totalCopies
    });
    setOpenDialog(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      try {
        await api.delete(`/books/${id}`);
        setSuccess('Book deleted successfully');
        fetchBooks();
      } catch (error) {
        setError('Failed to delete book');
      }
    }
  };

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.isbn.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (currentUser.role !== 'LIBRARIAN') {
    return (
      <Container>
        <Alert severity="error">Unauthorized access. Librarian role required.</Alert>
      </Container>
    );
  }

  return (
    <Container>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Book Management</Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => setOpenDialog(true)}
        >
          Add Book
        </Button>
      </Box>

      <TextField
        fullWidth
        label="Search Books"
        variant="outlined"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        sx={{ mb: 3 }}
        InputProps={{
          startAdornment: <Search sx={{ mr: 1, color: 'text.secondary' }} />
        }}
      />

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ISBN</TableCell>
              <TableCell>Title</TableCell>
              <TableCell>Author</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>Year</TableCell>
              <TableCell>Total Copies</TableCell>
              <TableCell>Available</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredBooks.map((book) => (
              <TableRow key={book.id}>
                <TableCell>{book.isbn}</TableCell>
                <TableCell>{book.title}</TableCell>
                <TableCell>{book.author}</TableCell>
                <TableCell>{book.category}</TableCell>
                <TableCell>{book.publicationYear}</TableCell>
                <TableCell>{book.totalCopies}</TableCell>
                <TableCell>{book.availableCopies}</TableCell>
                <TableCell>
                  <IconButton onClick={() => handleEdit(book)}>
                    <Edit />
                  </IconButton>
                  <IconButton onClick={() => handleDelete(book.id)}>
                    <Delete />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>{editingBook ? 'Edit Book' : 'Add New Book'}</DialogTitle>
        <form onSubmit={handleSubmit}>
          <DialogContent>
            <TextField
              margin="dense"
              label="ISBN"
              fullWidth
              required
              value={formData.isbn}
              onChange={(e) => setFormData({...formData, isbn: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Title"
              fullWidth
              required
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Author"
              fullWidth
              required
              value={formData.author}
              onChange={(e) => setFormData({...formData, author: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Category"
              fullWidth
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Publication Year"
              type="number"
              fullWidth
              value={formData.publicationYear}
              onChange={(e) => setFormData({...formData, publicationYear: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Total Copies"
              type="number"
              fullWidth
              required
              value={formData.totalCopies}
              onChange={(e) => setFormData({...formData, totalCopies: e.target.value})}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
            <Button type="submit" variant="contained">
              {editingBook ? 'Update' : 'Add'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </Container>
  );
};

export default BookManagement;