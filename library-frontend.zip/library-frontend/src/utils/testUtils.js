// Mock data for testing
export const mockBooks = [
  {
    id: 1,
    isbn: '1234567890',
    title: 'Test Book 1',
    author: 'Author 1',
    category: 'Fiction',
    publicationYear: 2020,
    copiesAvailable: 5,
    status: 'AVAILABLE'
  },
  {
    id: 2,
    isbn: '0987654321',
    title: 'Test Book 2',
    author: 'Author 2',
    category: 'Non-Fiction',
    publicationYear: 2021,
    copiesAvailable: 0,
    status: 'BORROWED'
  }
];

export const mockUsers = [
  {
    id: 1,
    firstName: 'John',
    lastName: 'Doe',
    email: 'john@example.com',
    role: 'MEMBER'
  }
];

export const mockBorrowingRecords = [
  {
    id: 1,
    book: mockBooks[0],
    user: mockUsers[0],
    borrowDate: '2023-01-01',
    dueDate: '2023-01-15',
    returnDate: null,
    renewalCount: 0,
    fineAmount: 0,
    status: 'BORROWED'
  }
];